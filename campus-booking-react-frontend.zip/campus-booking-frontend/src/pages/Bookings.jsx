import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../hooks/useToast';
import {
  getAllBookings, getAllFacilities, createBooking, updateBooking,
  cancelBooking, checkAvailability
} from '../api/client';
import Modal from '../components/Modal';
import { format, parseISO, isFuture } from 'date-fns';
import {
  CalendarDays, Clock, Search, Plus, Edit3, XCircle,
  CheckCircle2, Filter, Loader2, Building2
} from 'lucide-react';

const today = new Date().toISOString().split('T')[0];

const emptyForm = {
  facilityId: '',
  date: today,
  startTime: '09:00',
  endTime: '10:00',
};

function toApiTime(t) { return t && t.length === 5 ? t + ':00' : t; }
function fmtTime(t) { return t ? String(t).slice(0, 5) : ''; }

export default function Bookings() {
  const { user, isAdmin } = useAuth();
  const toast = useToast();

  const [bookings, setBookings] = useState([]);
  const [facilities, setFacilities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [activeTab, setActiveTab] = useState('upcoming'); // 'upcoming' | 'all' | 'cancelled'

  // Modal
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  // Availability
  const [avail, setAvail] = useState(null); // null | 'checking' | true | false
  const [availTimer, setAvailTimer] = useState(null);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    const [[bData], [fData]] = await Promise.all([getAllBookings(), getAllFacilities()]);
    setBookings(bData || []);
    setFacilities(fData || []);
    setLoading(false);
  }

  function openCreate() {
    setForm(emptyForm);
    setSelected(null);
    setAvail(null);
    setModal('create');
  }

  function openEdit(b) {
    const facility = facilities.find(f => f.name === b.facilityName);
    setForm({
      facilityId: String(facility?.id || ''),
      date: b.date,
      startTime: fmtTime(b.startTime),
      endTime: fmtTime(b.endTime),
    });
    setSelected(b);
    setAvail(null);
    setModal('edit');
  }

  function closeModal() { setModal(null); setSelected(null); setAvail(null); }

  function setField(field) {
    return e => {
      setForm(f => ({ ...f, [field]: e.target.value }));
      setAvail(null);
    };
  }

  // Debounced availability check
  const triggerAvailCheck = useCallback((f) => {
    if (!f.facilityId || !f.date || !f.startTime || !f.endTime) return;
    if (availTimer) clearTimeout(availTimer);
    setAvail('checking');
    const timer = setTimeout(async () => {
      const [data, err] = await checkAvailability(
        f.facilityId, f.date, toApiTime(f.startTime), toApiTime(f.endTime)
      );
      if (!err && data !== null) setAvail(data);
      else setAvail(null);
    }, 600);
    setAvailTimer(timer);
  }, [availTimer]);

  useEffect(() => {
    if (modal === 'create' || modal === 'edit') triggerAvailCheck(form);
  }, [form.facilityId, form.date, form.startTime, form.endTime]);

  async function handleSave() {
    if (!form.facilityId || !form.date || !form.startTime || !form.endTime) {
      toast('Please fill in all fields.', 'error'); return;
    }
    if (form.startTime >= form.endTime) {
      toast('End time must be after start time.', 'error'); return;
    }
    if (avail === false) {
      toast('This facility is not available for the selected time slot.', 'error'); return;
    }
    setSaving(true);
    const payload = {
      facilityId: Number(form.facilityId),
      userId: user.id,
      date: form.date,
      startTime: toApiTime(form.startTime),
      endTime: toApiTime(form.endTime),
    };
    const [data, err] = modal === 'create'
      ? await createBooking(payload)
      : await updateBooking(selected.id, payload);
    setSaving(false);
    if (err) { toast(err, 'error'); return; }
    if (modal === 'create') setBookings(prev => [...prev, data]);
    else setBookings(prev => prev.map(b => b.id === selected.id ? data : b));
    toast(modal === 'create' ? 'Booking confirmed!' : 'Booking updated!', 'success');
    closeModal();
  }

  async function handleCancel(id) {
    if (!confirm('Cancel this booking?')) return;
    const [, err] = await cancelBooking(id);
    if (err) { toast(err, 'error'); return; }
    setBookings(prev => prev.filter(b => b.id !== id));
    toast('Booking cancelled.', 'info');
  }

  // Filter logic
  const myBookings = isAdmin
    ? bookings
    : bookings.filter(b => b.userName === (user?.name || user?.email) || b.userName === user?.email);

  const tabFiltered = myBookings.filter(b => {
    if (activeTab === 'upcoming') return b.status === 'CONFIRMED' && isFuture(parseISO(b.date));
    if (activeTab === 'cancelled') return b.status === 'CANCELLED';
    return true;
  });

  const displayed = tabFiltered.filter(b => {
    const q = search.toLowerCase();
    return !q ||
      b.facilityName?.toLowerCase().includes(q) ||
      b.userName?.toLowerCase().includes(q) ||
      b.date?.includes(q);
  });

  const AvailBadge = () => {
    if (avail === null) return null;
    if (avail === 'checking') return (
      <div className="availability-indicator">
        <div className="avail-dot checking" />
        <span style={{ color: 'var(--warning)', fontSize: '0.8rem' }}>Checking availability…</span>
      </div>
    );
    if (avail === true) return (
      <div className="availability-indicator">
        <div className="avail-dot green" />
        <span style={{ color: 'var(--success)', fontSize: '0.8rem' }}>Available for this time slot</span>
      </div>
    );
    return (
      <div className="availability-indicator">
        <div className="avail-dot red" />
        <span style={{ color: 'var(--danger)', fontSize: '0.8rem' }}>Not available — time slot is taken</span>
      </div>
    );
  };

  const BookingForm = () => (
    <>
      <div className="form-group">
        <label className="form-label">Facility</label>
        <select className="form-control" value={form.facilityId} onChange={setField('facilityId')}>
          <option value="">Select a facility…</option>
          {facilities.map(f => (
            <option key={f.id} value={f.id}>{f.name} — {f.location} (cap. {f.capacity})</option>
          ))}
        </select>
      </div>
      <div className="form-group">
        <label className="form-label">Date</label>
        <input type="date" className="form-control" value={form.date} min={today} onChange={setField('date')} />
      </div>
      <div className="grid grid-2">
        <div className="form-group">
          <label className="form-label">Start Time</label>
          <input type="time" className="form-control" value={form.startTime} onChange={setField('startTime')} />
        </div>
        <div className="form-group">
          <label className="form-label">End Time</label>
          <input type="time" className="form-control" value={form.endTime} onChange={setField('endTime')} />
        </div>
      </div>
      <AvailBadge />
    </>
  );

  return (
    <div className="page-wrapper page-enter">
      <div className="page-header">
        <div className="page-title">
          <span>Reservations</span>
          <h1>{isAdmin ? 'All Bookings' : 'My Bookings'}</h1>
        </div>
        <button className="btn btn-primary" onClick={openCreate}>
          <Plus size={15} /> New Booking
        </button>
      </div>

      {/* Tabs */}
      <div className="tabs">
        {[
          { id: 'upcoming', label: 'Upcoming' },
          { id: 'all', label: `All (${myBookings.length})` },
          { id: 'cancelled', label: 'Cancelled' },
        ].map(t => (
          <button
            key={t.id}
            className={`tab-btn ${activeTab === t.id ? 'active' : ''}`}
            onClick={() => setActiveTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Filter bar */}
      <div className="filter-bar">
        <div className="search-input-wrap">
          <Search size={15} />
          <input
            className="form-control"
            placeholder="Search by facility, user, or date…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', alignSelf: 'center' }}>
          {displayed.length} booking{displayed.length !== 1 ? 's' : ''}
        </span>
      </div>

      {loading ? (
        <div className="loading-page"><div className="spinner" /><span>Loading bookings…</span></div>
      ) : displayed.length === 0 ? (
        <div className="empty-state">
          <CalendarDays size={48} />
          <h3>{search ? 'No matching bookings' : 'No bookings found'}</h3>
          <p>{activeTab === 'upcoming' ? 'You have no upcoming reservations.' : 'Nothing to show here.'}</p>
        </div>
      ) : (
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Facility</th>
                {isAdmin && <th>User</th>}
                <th>Date</th>
                <th>Time</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {displayed.map(b => (
                <tr key={b.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <Building2 size={14} color="var(--gold)" />
                      <strong>{b.facilityName}</strong>
                    </div>
                  </td>
                  {isAdmin && <td style={{ color: 'var(--text-secondary)', fontSize: '0.82rem' }}>{b.userName}</td>}
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.875rem' }}>
                      <CalendarDays size={13} color="var(--text-muted)" />
                      {format(parseISO(b.date), 'EEE, MMM d, yyyy')}
                    </div>
                  </td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                      <Clock size={13} />
                      {fmtTime(b.startTime)} – {fmtTime(b.endTime)}
                    </div>
                  </td>
                  <td>
                    <span className={`badge badge-${b.status?.toLowerCase()}`}>{b.status}</span>
                  </td>
                  <td>
                    <div className="td-actions">
                      {b.status === 'CONFIRMED' && isFuture(parseISO(b.date)) && (
                        <button className="btn btn-ghost btn-sm" onClick={() => openEdit(b)}>
                          <Edit3 size={13} /> Edit
                        </button>
                      )}
                      {b.status === 'CONFIRMED' && (
                        <button className="btn btn-danger btn-sm" onClick={() => handleCancel(b.id)}>
                          <XCircle size={13} /> Cancel
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Create / Edit Modal */}
      <Modal
        open={modal === 'create' || modal === 'edit'}
        title={modal === 'create' ? 'New Booking' : 'Edit Booking'}
        onClose={closeModal}
        footer={
          <>
            <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
            <button
              className="btn btn-primary"
              onClick={handleSave}
              disabled={saving || avail === false}
            >
              {saving ? <Loader2 size={15} /> : <CheckCircle2 size={15} />}
              {modal === 'create' ? 'Confirm Booking' : 'Save Changes'}
            </button>
          </>
        }
      >
        <BookingForm />
      </Modal>
    </div>
  );
}
