import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../hooks/useToast';
import { getAllBookings, getAllFacilities, cancelBooking } from '../api/client';
import { format, isToday, isFuture, parseISO } from 'date-fns';
import { CalendarDays, Building2, Clock, CheckCircle2, XCircle, Plus, ArrowRight } from 'lucide-react';

export default function Dashboard() {
  const { user } = useAuth();
  const toast = useToast();
  const [bookings, setBookings] = useState([]);
  const [facilities, setFacilities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [[bData], [fData]] = await Promise.all([getAllBookings(), getAllFacilities()]);
      // Filter to current user's bookings
      const myBookings = (bData || []).filter(b => b.userName === (user?.name || user?.email));
      setBookings(myBookings);
      setFacilities((fData || []).slice(0, 6));
      setLoading(false);
    }
    load();
  }, [user]);

  async function handleCancel(id) {
    if (!confirm('Cancel this booking?')) return;
    const [, err] = await cancelBooking(id);
    if (err) { toast(err, 'error'); return; }
    setBookings(prev => prev.filter(b => b.id !== id));
    toast('Booking cancelled.', 'info');
  }

  const upcoming = bookings.filter(b => b.status === 'CONFIRMED' && isFuture(parseISO(b.date)));
  const todayBookings = bookings.filter(b => isToday(parseISO(b.date)) && b.status === 'CONFIRMED');
  const confirmed = bookings.filter(b => b.status === 'CONFIRMED');
  const cancelled = bookings.filter(b => b.status === 'CANCELLED');

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  if (loading) return (
    <div className="page-wrapper loading-page">
      <div className="spinner" /><span>Loading your dashboard…</span>
    </div>
  );

  return (
    <div className="page-wrapper page-enter">
      {/* Welcome banner */}
      <div className="welcome-banner">
        <div>
          <h2>{greeting()}, {user?.name || 'there'} 👋</h2>
          <p>Here's a summary of your campus bookings for today and upcoming days.</p>
        </div>
        <Link to="/bookings" className="btn btn-primary">
          <Plus size={15} />New Booking
        </Link>
      </div>

      {/* Stats row */}
      <div className="grid grid-4" style={{ marginBottom: '2rem' }}>
        <div className="stat-card gold">
          <Building2 size={32} className="stat-icon" />
          <div className="stat-number">{facilities.length}</div>
          <div className="stat-label">Available Facilities</div>
        </div>
        <div className="stat-card blue">
          <CalendarDays size={32} className="stat-icon" />
          <div className="stat-number">{upcoming.length}</div>
          <div className="stat-label">Upcoming Bookings</div>
        </div>
        <div className="stat-card green">
          <CheckCircle2 size={32} className="stat-icon" />
          <div className="stat-number">{todayBookings.length}</div>
          <div className="stat-label">Today's Bookings</div>
        </div>
        <div className="stat-card red">
          <XCircle size={32} className="stat-icon" />
          <div className="stat-number">{cancelled.length}</div>
          <div className="stat-label">Cancelled</div>
        </div>
      </div>

      <div className="grid grid-2" style={{ gap: '1.5rem' }}>
        {/* Upcoming bookings */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h2 style={{ fontSize: '1.1rem' }}>Upcoming Bookings</h2>
            <Link to="/bookings" className="btn btn-ghost btn-sm">View all <ArrowRight size={13} /></Link>
          </div>

          {upcoming.length === 0 ? (
            <div className="card empty-state">
              <CalendarDays size={36} />
              <h3>No upcoming bookings</h3>
              <p>Reserve a facility to get started</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {upcoming.slice(0, 5).map(b => (
                <div key={b.id} className="card" style={{ padding: '1rem 1.25rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, marginBottom: '0.3rem' }}>{b.facilityName}</div>
                      <div style={{ display: 'flex', gap: '1rem', fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                          <CalendarDays size={12} />{format(parseISO(b.date), 'MMM d, yyyy')}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                          <Clock size={12} />{b.startTime?.slice(0, 5)} – {b.endTime?.slice(0, 5)}
                        </span>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span className={`badge badge-${b.status?.toLowerCase()}`}>{b.status}</span>
                      <button className="btn btn-danger btn-sm" onClick={() => handleCancel(b.id)}>Cancel</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick access facilities */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h2 style={{ fontSize: '1.1rem' }}>Available Facilities</h2>
            <Link to="/facilities" className="btn btn-ghost btn-sm">Browse all <ArrowRight size={13} /></Link>
          </div>

          {facilities.length === 0 ? (
            <div className="card empty-state">
              <Building2 size={36} />
              <h3>No facilities yet</h3>
              <p>Check back later</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {facilities.map(f => (
                <div key={f.id} className="card" style={{ padding: '1rem 1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div>
                    <div style={{ fontWeight: 600, marginBottom: '0.2rem' }}>{f.name}</div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                      {f.location} · Capacity {f.capacity}
                    </div>
                  </div>
                  <Link to="/bookings" className="btn btn-primary btn-sm">Book</Link>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
