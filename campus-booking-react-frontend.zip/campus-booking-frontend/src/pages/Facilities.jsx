import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../hooks/useToast';
import {
  getAllFacilities, createFacility, updateFacility, deleteFacility
} from '../api/client';
import Modal from '../components/Modal';
import {
  Building2, MapPin, Users, Search, Plus, Edit3, Trash2,
  Loader2, LayoutGrid, List
} from 'lucide-react';

const emptyForm = { name: '', location: '', capacity: '' };

export default function Facilities() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const [facilities, setFacilities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [view, setView] = useState('grid'); // 'grid' | 'list'

  // Modal state
  const [modal, setModal] = useState(null); // null | 'create' | 'edit' | 'delete'
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    const [data, err] = await getAllFacilities();
    if (err) toast(err, 'error');
    else setFacilities(data || []);
    setLoading(false);
  }

  function openCreate() { setForm(emptyForm); setSelected(null); setModal('create'); }
  function openEdit(f) { setForm({ name: f.name, location: f.location, capacity: String(f.capacity) }); setSelected(f); setModal('edit'); }
  function openDelete(f) { setSelected(f); setModal('delete'); }
  function closeModal() { setModal(null); setSelected(null); }

  function setField(field) { return e => setForm(f => ({ ...f, [field]: e.target.value })); }

  async function handleSave() {
    if (!form.name.trim() || !form.location.trim() || !form.capacity) {
      toast('All fields are required.', 'error'); return;
    }
    if (Number(form.capacity) < 1) {
      toast('Capacity must be at least 1.', 'error'); return;
    }
    setSaving(true);
    const payload = { name: form.name.trim(), location: form.location.trim(), capacity: Number(form.capacity) };
    const [data, err] = modal === 'create'
      ? await createFacility(payload)
      : await updateFacility(selected.id, payload);
    setSaving(false);
    if (err) { toast(err, 'error'); return; }
    if (modal === 'create') setFacilities(f => [...f, data]);
    else setFacilities(f => f.map(x => x.id === selected.id ? data : x));
    toast(modal === 'create' ? 'Facility created!' : 'Facility updated!', 'success');
    closeModal();
  }

  async function handleDelete() {
    setSaving(true);
    const [, err] = await deleteFacility(selected.id);
    setSaving(false);
    if (err) { toast(err, 'error'); return; }
    setFacilities(f => f.filter(x => x.id !== selected.id));
    toast('Facility deleted.', 'info');
    closeModal();
  }

  const filtered = facilities.filter(f =>
    f.name.toLowerCase().includes(search.toLowerCase()) ||
    f.location.toLowerCase().includes(search.toLowerCase())
  );

  const FacilityForm = () => (
    <>
      <div className="form-group">
        <label className="form-label">Facility Name</label>
        <input className="form-control" placeholder="e.g. Main Auditorium" value={form.name} onChange={setField('name')} />
      </div>
      <div className="form-group">
        <label className="form-label">Location</label>
        <input className="form-control" placeholder="e.g. Block A, Room 101" value={form.location} onChange={setField('location')} />
      </div>
      <div className="form-group">
        <label className="form-label">Capacity (persons)</label>
        <input className="form-control" type="number" min="1" placeholder="50" value={form.capacity} onChange={setField('capacity')} />
      </div>
    </>
  );

  return (
    <div className="page-wrapper page-enter">
      <div className="page-header">
        <div className="page-title">
          <span>Campus Resources</span>
          <h1>Facilities</h1>
        </div>
        {isAdmin && (
          <button className="btn btn-primary" onClick={openCreate}>
            <Plus size={15} /> Add Facility
          </button>
        )}
      </div>

      {/* Filter bar */}
      <div className="filter-bar">
        <div className="search-input-wrap">
          <Search size={15} />
          <input
            className="form-control"
            placeholder="Search by name or location…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div style={{ display: 'flex', gap: '0.25rem' }}>
          <button
            className={`btn btn-sm ${view === 'grid' ? 'btn-secondary' : 'btn-ghost'}`}
            onClick={() => setView('grid')}
          ><LayoutGrid size={14} /></button>
          <button
            className={`btn btn-sm ${view === 'list' ? 'btn-secondary' : 'btn-ghost'}`}
            onClick={() => setView('list')}
          ><List size={14} /></button>
        </div>
        <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', alignSelf: 'center' }}>
          {filtered.length} facilit{filtered.length !== 1 ? 'ies' : 'y'}
        </span>
      </div>

      {loading ? (
        <div className="loading-page"><div className="spinner" /><span>Loading facilities…</span></div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <Building2 size={48} />
          <h3>{search ? 'No matching facilities' : 'No facilities yet'}</h3>
          <p>{search ? 'Try a different search term' : isAdmin ? 'Add your first facility to get started' : 'Check back later'}</p>
        </div>
      ) : view === 'grid' ? (
        <div className="grid grid-3">
          {filtered.map(f => (
            <div key={f.id} className="card facility-card">
              <div className="facility-card-header">
                <div>
                  <div className="facility-card-title">{f.name}</div>
                </div>
                <div style={{ background: 'var(--gold-dim)', padding: '0.35rem 0.6rem', borderRadius: '6px' }}>
                  <Building2 size={18} color="var(--gold)" />
                </div>
              </div>
              <div className="facility-card-meta">
                <span><MapPin size={13} />{f.location}</span>
                <span><Users size={13} />Capacity: {f.capacity} persons</span>
              </div>
              {isAdmin && (
                <div className="facility-card-footer">
                  <button className="btn btn-ghost btn-sm" style={{ flex: 1 }} onClick={() => openEdit(f)}>
                    <Edit3 size={13} /> Edit
                  </button>
                  <button className="btn btn-danger btn-sm" style={{ flex: 1 }} onClick={() => openDelete(f)}>
                    <Trash2 size={13} /> Delete
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Location</th>
                <th>Capacity</th>
                {isAdmin && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {filtered.map((f, i) => (
                <tr key={f.id}>
                  <td style={{ color: 'var(--text-muted)' }}>{i + 1}</td>
                  <td><strong>{f.name}</strong></td>
                  <td style={{ color: 'var(--text-secondary)' }}>{f.location}</td>
                  <td>{f.capacity} persons</td>
                  {isAdmin && (
                    <td>
                      <div className="td-actions">
                        <button className="btn btn-ghost btn-sm" onClick={() => openEdit(f)}>
                          <Edit3 size={13} /> Edit
                        </button>
                        <button className="btn btn-danger btn-sm" onClick={() => openDelete(f)}>
                          <Trash2 size={13} /> Delete
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Create / Edit Modal */}
      <Modal
        open={modal === 'create' || modal === 'edit'}
        title={modal === 'create' ? 'Add New Facility' : 'Edit Facility'}
        onClose={closeModal}
        footer={
          <>
            <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
            <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
              {saving ? <Loader2 size={15} /> : null}
              {modal === 'create' ? 'Create Facility' : 'Save Changes'}
            </button>
          </>
        }
      >
        <FacilityForm />
      </Modal>

      {/* Delete confirmation Modal */}
      <Modal
        open={modal === 'delete'}
        title="Delete Facility"
        onClose={closeModal}
        size="sm"
        footer={
          <>
            <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
            <button className="btn btn-danger" onClick={handleDelete} disabled={saving}>
              {saving ? <Loader2 size={15} /> : <Trash2 size={14} />}
              Delete
            </button>
          </>
        }
      >
        <p style={{ color: 'var(--text-secondary)' }}>
          Are you sure you want to delete <strong style={{ color: 'var(--text-primary)' }}>{selected?.name}</strong>?
          This action cannot be undone and will remove all associated bookings.
        </p>
      </Modal>
    </div>
  );
}
